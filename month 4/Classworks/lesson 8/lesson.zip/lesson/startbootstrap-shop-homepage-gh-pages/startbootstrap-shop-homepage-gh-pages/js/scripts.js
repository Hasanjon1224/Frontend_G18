/*!
 * Start Bootstrap - Shop Homepage v5.0.6 (https://startbootstrap.com/template/shop-homepage)
 * Copyright 2013-2023 Start Bootstrap
 * Licensed under MIT (https://github.com/StartBootstrap/startbootstrap-shop-homepage/blob/master/LICENSE)
 */
// This file is intentionally blank
// Use this file to add JavaScript to your project

// Meta tegi yaratish funksiyasi
function createMetaTag(name, content) {
  let metaTag = document.createElement('meta');
  metaTag.name = name;
  metaTag.content = content;
  document.head.appendChild(metaTag);
}

// Meta teglarni yangilash funksiyasi
function updateMetaTag(name, content) {
  let metaTag = document.querySelector(`meta[name="${name}"]`);
  if (metaTag) {
      metaTag.content = content;
  } else {
      createMetaTag(name, content);
  }
}

// Meta teglarni yaratish yoki yangilash
updateMetaTag('description', 'Bu sahifaning yangilangan tavsifi');
updateMetaTag('keywords', 'yangi, kalit, so\'zlar');


// Sahifa yuklanganda meta teglarni o'rnatish
document.addEventListener('DOMContentLoaded', () => {
  updateMetaTag('description', 'Bu sahifaning yangilangan tavsifi');
  updateMetaTag('keywords', 'yangi, kalit, so\'zlar');
});

// Dinamik kontent o'zgarganda meta teglarni yangilash
function onContentChange(newDescription, newKeywords) {
  updateMetaTag('description', newDescription);
  updateMetaTag('keywords', newKeywords);
}

// Misol uchun, kontent o'zgarganda meta teglarni yangilash
onContentChange('Bu yangi kontentning tavsifi', 'yangi, dinamik, kalit so\'zlar');





































const cardWrapper = document.getElementById("cardWrapper");
cardWrapper.innerHTML = "";
const loadingHtml = `<div class="mx-auto spinner-border text-primary" role="status"><span class="visually-hidden">Loading</span></div>`;

fetch("https://fakestoreapi.com/products/", {
  method: "GET",
})
  .then((res) => res.json())
  .then((json) =>
    json.forEach((element) => {
   
      printProduct(element);
    })
  );

function printProduct(product) {
  const title = product.title.split(" ").slice(0, 2).join(" ");
  const sale = product.rating.count <= 250;
  const stars = Math.round(product.rating.rate);
  let star = '';
  for (let i = 0; i < stars; i++) {
   star += "<div class='bi-star-fill'></div>"
    
  }
  cardWrapper.innerHTML += ` <div class="col mb-5">
            <div class="card h-100">
           ${
             sale
               ? `<div
                class="badge bg-dark text-white position-absolute"
                style="top: 0.5rem; right: 0.5rem"
              >
                Sale
              </div>`
               : ""
           }
              
             
              <img
                class="card-img-top p-4 object-fit-contain"
                src="${product.image}"
                alt="${title}"
              height="300" loading = "lazy"/>
             
              <div class="card-body p-4">
                <div class="text-center">
               
                  <h5 class="fw-bolder">${title}...</h5>
              <div class="d-flex justify-content-center small text-warning mb-2"> 
               ${star}    
              </div>
                
                 
                  $ ${product.price} 
                </div>
              </div>
           
              <div class="card-footer p-4 pt-0 border-top-0 bg-transparent">
                <div class="text-center">
                  <a class="btn btn-outline-dark mt-auto" href="#"
                    >Add to cart</a
                  >
                </div>
              </div>
            </div>
          </div>`;
}

printProduct();
